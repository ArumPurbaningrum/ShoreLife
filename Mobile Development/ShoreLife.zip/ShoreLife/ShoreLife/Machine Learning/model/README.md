# Machine Learning Model

- ML Model for 5 classes: https://drive.google.com/drive/folders/1ZGsjDlNRDNvz7mEE_criT1IQyMkq6pjs?usp=drive_link
- ML Model for 10 classes: https://drive.google.com/drive/folders/1n2D5uuFHCg0OF12ypu7deM26K8ZazGPU?usp=drive_link
